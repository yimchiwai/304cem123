var http = require('http');
var fs = require("fs");
var qs = require('querystring');
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;

//var dbUrl = "mongodb://localhost:27017/";
var dbUrl = "mongodb://localhost:32768/";
//var loginstatus="";
http.createServer(function(request, response) {

	if(request.url === "/"){
		console.log("Requested URL is url" +request.url);
		sendFileContent(response, "index.html", "text/html");
	}
	else if(request.url === "/home"){
		console.log("Requested URL is url" +request.url);
		sendFileContent(response, "home.html", "text/html");
	}
	else if(request.url === "/logout"){
		console.log("Requested URL is url" +request.url);
		sendFileContent(response, "logout.html", "text/html");
	}
	else if(request.url === "/check_fav"){
		console.log("Requested URL is url" +request.url);
		if(request.method==="POST"){
			formData = '';
			return request.on('data', function(data) {
				formData+=data;
				console.log(formData);
				data= qs.parse(formData);
				var query={"loginid": data["loginid"]};
				return request.on('end', function() {
				MongoClient.connect(dbUrl, function(err, db) {
					if (err) throw err;
						var dbo = db.db("mydb");
						dbo.collection("fav_list").find(query).sort({_id:-1}).toArray(function(err, result) {
							if (err) throw err;
							db.close();
							//console.log(array.login);
							return response.end(JSON.stringify(result));
				
						});
				});
			});
			});
		}else{
				console.log("check Fav not POST");
				console.log("Requested URL is url" +request.url);
				formData = '';
				
				MongoClient.connect(dbUrl, function(err, db) {
					if (err) throw err;
					var dbo = db.db("mydb");
					dbo.collection("fav_list").find({}).sort({_id:-1}).toArray(function(err, result) {
						if (err) throw err;
						db.close();
				//console.log(array.login);
						return response.end(JSON.stringify(result));
				
					});
				});
			}		
		
	}

	else if(request.url==="/mail"){
		console.log("Requested URL is url" +request.url);
		if(request.method==="POST"){
			formData = '';
			msg = '';
			
			return request.on('data', function(data) {
				//console.log(data);
				formData+=data;
				//console.log(formData);
				return request.on('end', function() {

					
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
						var dbo = db.db("mydb");
						data= qs.parse(formData);
						//console.log(data["loginid"]+"@@@@@@@");

						var query={login:data["loginid"]};
						console.log(query);
						dbo.collection("customers").findOne(query,function(err, result) {
							if (err) throw err;
								console.log(JSON.stringify(result.login));
								console.log(JSON.stringify(result.password));
								console.log(JSON.stringify(result.mail));
								var transporter = nodemailer.createTransport({
									service: 'gmail',
									auth: {
										user: '',
										pass: ''
									}
								});

								var mailOptions = {
									from: 'yimchiwai1983@gmail.com',
									to: JSON.stringify(result.mail),
									subject: 'Tommy Book Store Password',
									html: "Password:"+JSON.stringify(result.password)
								};

								transporter.sendMail(mailOptions, function(error, info){
								if (error) {
									console.log(error);
								} else {
									console.log('Email sent: ' + info.response +":"+JSON.stringify(result.mail));
								}		
							});	
							response.end("Mail sent");
							db.close();
						
						});
					});
				});
			});
		}else{
				console.log("forgot PW-not POST");
				sendFileContent(response, "forgotpw.html", "text/html");
		}
	}
	
	else if(request.url === "/my_fav"){
		console.log("Requested URL is url" +request.url);
		if (request.method === "POST") {
			formData = '';
			msg = '';
			return request.on('data', function(data) {
				console.log("check fav");
				console.log(data);
				formData += data;
				console.log(formData);
				return request.on('end', function() {
					
					//user = qs.parse(formData);
					//data = JSON.stringify(data);
					//loginstatus=0;
					//stringMsg = JSON.parse(msg);
					//console.log(msg);
					MongoClient.connect(dbUrl, function(err, db) {
						
						
						if (err) throw err;
						var dbo = db.db("mydb");
						var str = "";
						//console.log(stringMsg);
						console.log(msg);
						var query={loginid: formData};
						dbo.collection("fav_list").find(query).sort({_id:-1}).toArray(function(err, result) {
							if (err) throw err;
							//console.log(result);
							var array=[];
							str="<table>";
							str+="<tr>";
							for (var i=0;i<result.length;i++){

								//str+="<td><img src='" + result[i].bookid +"&printsec="+result[i].printsec+"&img="+result[i].img+"&zoom="+result[i].zoom+"&edge="+result[i].edge+"&source="+result[i].source+"&loginid="+result[i].loginid+"'></td>";
								str+="<td><img src='http://books.google.com/books/content?id="+result[i].bookid+"&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'></td>";

							}
							str+="</tr>";
							str+="<tr>";
							for (var i=0;i<result.length;i++){
								str+="<td><button onclick=getbook('bookid="+ result[i].bookid +"&loginid="+result[i].loginid+"')>Remove</button></td>";
							}
							str+="</tr>";
							str=str+"<table>";
							str=str+"<input id='bookid' type='text' placeholder='Enter book ID' name='bookid' required>";
							array.push(str);
							db.close();
							//console.log(array.login);
							return response.end(array.toString());
							
						});

						
					});
				});
			});	
		}else{
				console.log("ff");
				sendFileContent(response, "my_fav.html", "text/html");
		}
	}
	else if(request.url === "/login"){
		console.log("-->login");
		formData = '';
		console.log("Requested URL is url" +request.url);
		if (request.method === "POST") {
			return request.on('data', function(data) {
				console.log("POST OK");
				formData += data;
				console.log(formData);
				return request.on('end', function() {
					var user;
					user = qs.parse(formData);
					msg = JSON.stringify(user);
					//loginstatus=0;
					stringMsg = JSON.parse(msg);
					MongoClient.connect(dbUrl, function(err, db) {
						
						
						if (err) throw err;
						var dbo = db.db("mydb");
						console.log(stringMsg);
						dbo.collection("customers").find(stringMsg).toArray(function(err, result) {
							if (err) throw err;
							console.log(result);
							if(result!=""){
								console.log("login ok");
								loginstatus="1";
							}else{
								console.log("No record");
								loginstatus="0";
							}
							db.close();
						
						
							if(loginstatus==="1"){
								//response.end(loginstatus);
								response.end("login_ok");
							}else{
								//response.end(loginstatus);
								response.end("login_fail");
							}
							
							
							
						});

						
					});
				});
			});
			
		}else{
				sendFileContent(response, "login.html", "text/html");
			}
	}
    else if(request.url==="/reg"){
        console.log("Requested URL is url" +request.url+"*****");     
        if (request.method === "POST") {
            console.log("Create Account");
			formData = '';
			msg = '';
			return request.on('data', function(data) {
				formData += data;
				var r = Math.random().toString(36).substring(3);
				formData+="&key="+r;
				//console.log(formData);
		
				return request.on('end', function() {
					var user;

					user = qs.parse(formData);
					msg = JSON.stringify(user);
					stringMsg = JSON.parse(msg);
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
							var dbo = db.db("mydb");
							var myobj = stringMsg;
							dbo.collection("customers").insertOne(myobj, function(err, res) {
								if (err) throw err;
								console.log("1 document inserted");
								response.end("Account created!!");
								db.close();
							});
						});
			
				});

			}); 
		} else {
			sendFileContent(response, "reg.html", "text/html");
		}
	}
    else if(request.url==="/comment"){
        console.log("Requested URL is url" +request.url+"*****");     
        if (request.method === "POST") {
			formData = '';
			msg = '';
			return request.on('data', function(data) {
				formData += data;
	
				return request.on('end', function() {
					var user;

					user = qs.parse(formData);

					msg = JSON.stringify(user);
					stringMsg = JSON.parse(msg);

					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
							var dbo = db.db("mydb");
							var myobj = stringMsg;
							dbo.collection("comment").insertOne(myobj, function(err, res) {
								if (err) throw err;
								console.log("comment inserted");
								response.end("Thank you for your comment!!");
								db.close();
							});
						});
			
				});

			}); 
		} else {
			sendFileContent(response, "index.html", "text/html");
		}
	}
    else if(request.url==="/checkcomment"){
        console.log("Requested URL is url" +request.url+"*****");     
        if (request.method === "POST") {
			formData = '';
			msg = '';
			return request.on('data', function(data) {
				formData += data;
				//console.log(formData);
				return request.on('end', function() {
					var user;

					user = qs.parse(formData);
					console.log(user["bookid"]);		
					msg = JSON.stringify(user);
					stringMsg = JSON.parse(msg);

					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
							var dbo = db.db("mydb");
							var query={"bookid": user["bookid"]};
							console.log(query);
							dbo.collection("comment").find(query).toArray(function(err, result) {
								if (err) throw err;
								console.log("comment find");
								console.log(JSON.stringify(result));
								db.close();
								return response.end(JSON.stringify(result));
							});
						});
			
				});

			}); 
		} else {
			sendFileContent(response, "index.html", "text/html");
		}
	}	
	
	
	
	
	
    else if(request.url==="/book"){
        console.log("Requested URL is url" +request.url+"*****");     
        if (request.method === "POST") {
            //console.log("test");
			formData = '';
			msg = '';
			return request.on('data', function(data) {
				formData += data;
				console.log(formData);
		  
				return request.on('end', function() {
					var user;
					var data;
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
							var dbo = db.db("mydb");
							var myobj
							data= qs.parse(formData);
							console.log(data);
							msg = JSON.stringify(data);
							stringMsg = JSON.parse(msg);
							console.log(stringMsg);
							//myobj =stringMsg;
							dbo.collection("fav_list").insertOne(stringMsg, function(err, res) {
								if (err) throw err;
								console.log("1 document inserted@@@@@");
								db.close();
							});
							response.end("Added to Fav!!");
						});
			
				});

			}); 
		} else {
			sendFileContent(response, "book.html", "text/html");
		}
	}
	else if(request.url==="/removefav"){
		console.log("Requested URL is url" +request.url);
		if (request.method === "POST") {
			return request.on('data', function(data) {
				formData = '';
				formData += data;
				//console.log(formData);
				return request.on('end', function() {
					var user;
					var data;
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
						var dbo = db.db("mydb");
						data= qs.parse(formData);
						
						bookid=data["bookid"];
						//console.log(bookid);
						console.log(data["loginid"]);
						var query={bookid :bookid,loginid:data["loginid"]};
						dbo.collection("fav_list").deleteOne(query,function(err, result) {
							if (err) throw err;
								console.log("Deleted 1 record");
							db.close();
								response.end("Deleted 1 record");							
						});
					});
				}); 
			}); 
		}else {
			console.log("my_fav.html");
			sendFileContent(response, "my_fav.html", "text/html");
		}
	}
	else if(request.url==="/changepw"){
		console.log("Requested URL is url" +request.url);
		if (request.method === "POST") {
			return request.on('data', function(data) {
				formData = '';
				formData += data;
				//console.log(formData);
				return request.on('end', function() {
					var user;
					var data;
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
						var dbo = db.db("mydb");
						data= qs.parse(formData);
						
						//user=data["user"];
						//console.log(bookid);
						console.log(data["loginid"]);
						console.log(data["password"]);
						var query={login:data["loginid"]};
						var newvalues ={$set:{password:data["password"]}};
						dbo.collection("customers").updateOne(query,newvalues,function(err, result) {
							if (err) throw err;
								console.log(result.result.nModified+"Password Update!!");
							db.close();
							
							response.end("Password Updated.");	
						
						});
					});
				}); 
			}); 
		}else {
			console.log("changepw.html");
			sendFileContent(response, "changepw.html", "text/html");
		}
	}
	else if(/^\/[a-zA-Z0-9\/-/]*.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}else if(/^\/[a-zA-Z0-9\/-/]*.bundle.min.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}else if(/^\/[a-zA-Z0-9\/-/]*.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}else if(/^\/[a-zA-Z0-9\/-]*.min.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}else if(/^\/[a-zA-Z0-9\/-]*.jpg$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/jpg");
	}else if(/^\/[a-zA-Z0-9-._\/]*.min.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}else if(/^\/[a-zA-Z0-9-]*.min.css.map$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/map");
	}else if(/^\/[a-zA-Z0-9\/-/]*.min.js.map$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/map");
	}else if(/^\/[a-zA-Z0-9\/-/]*.css.map$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/map");
	}else if(/^\/[a-zA-Z0-9\/-/]*.png$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/png");
	}else if(/^\/[a-zA-Z0-9\/-/]*.ico$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/ico");
	}else if(/^\/[a-zA-Z0-9\/-/?]*.ttf$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/font");
	}else if(/^\/[a-zA-Z0-9\/-/?]*.woff$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/woff");
	}else if(/^\/[a-zA-Z0-9\/-/?]*.woff2$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/woff2");
	}else{
		console.log("Requested URL is: " + request.url);
		response.end();
	}
}).listen(9999)

function sendFileContent(response, fileName, contentType){
	fs.readFile(fileName, function(err, data){
		if(err){
			response.writeHead(404);
			response.write("Not Found!");
		}
		else{
			response.writeHead(200, {'Content-Type': contentType});
			response.write(data);
		}
		response.end();
	});
}